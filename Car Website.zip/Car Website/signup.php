<?php include ('includes/header.php'); ?>
<?php include('includes/connection.php');?>

    <div class="about" id="signup">
        <h1 id="signup-heading">SIGN UP</h1>

        <div id="form-signup">
            <form action="includes/createUser.php" method="post">
            <input type="text" placeholder="First Name" name="FName">
            <input type="text" placeholder="Last Name" name="LName">
            <input type="text" placeholder="User name or email address" name="UName">
            <input type="Password" placeholder="Password" name="Pass">
            <input type="Password" placeholder="Confirm Password" name="CPass">
            <button type="submit">Sign up</button>

            <p style="color: #000;"><a href="./login.php" style="color: #5ba3f0;">Already have an account? Login</a></p>
            </form>
        </div>
    </div>


    <!-- Social bar -->

    <div class="socialbar" id="signup-footer">
        <div class="container">
            <div class="row">

                <div class="col-md-12">
                    <ul>
                        <a href="">
                            <li><i class="fa fa-facebook"></i>Facebook</li>
                        </a>
                        <a href="">
                            <li><i class="fa fa-twitter"></i>Twitter</li>
                        </a>
                        <a href="">
                            <li><i class="fa fa-instagram"></i>Instagram</li>
                        </a>
                        <a href="">
                            <li><i class="fa fa-youtube-play"></i>Youtube</li>
                        </a>
                    </ul>
                </div>

            </div>
        </div>
    </div>

<?php include 'includes/footer.php'; ?>