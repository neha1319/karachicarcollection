<?php include 'includes/header.php'; ?>

  <h1 style="text-align: center;"><b>News Dashboard</b></h1>
  <br><br>
  <section>
    <div class="container">
      <div class="col-md-12">
        <div class="col-md-6">
    <div class="thumbnail">
      <div class="caption">
        <h3 style="text-align: center;"><a href="#">Auto-sector to grow in 2021</a></h3><br>
        <p style="text-align: justify;"><b>KARACHI: </b>Despite the negative impacts of the Covid-19 lockdown on Pakistan’s economy, experts see light at the end of the tunnel for the automobile industry. “Industry analysts have painted a positive outlook for the auto industry in the upcoming years, predicting around 17% rise in demand for cars in 2021 and 24% in 2022,” stated an OLX report on vehicle category.</p>
      </div>
      <div>
        <p style="text-align: center;"><a href="#">Read more</a></p>
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="thumbnail">
      <div class="caption">
        <h3 style="text-align: center;"><a href="#">Auto-makers urge PTI govt. not to liberalise used car imports</a></h3><br>
        <p style="text-align: justify;"><b>ISLAMABAD: </b>Domestic car manufacturers have warned the government that liberalisation of the import of used vehicles will lead to closure of the auto industry and hit plans of setting up new vehicle plants in Pakistan. “A meeting.....</p>
      </div>
      <div>
        <p style="text-align: center;"><a href="#">Read more</a></p>
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="thumbnail">
      <div class="caption">
        <h3 style="text-align: center;"><a href="#">Auto industry to pass impact of rupee fall to consumers</a></h3><br>
        <p style="text-align: justify;"><b>KARACHI: </b>The demand in the auto industry is strong and the rising cost of production due to rupee depreciation will be passed on to consumers. However, the cement industry will not be lucky enough to replicate the measures adopted by the auto industry to deal with the impact of currency weakness.</p>
      </div>
      <div>
        <p style="text-align: center;"><a href="#">Read more</a></p>
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="thumbnail">
      <div class="caption">
        <h3 style="text-align: center;"><a href="#">Honda Pakistan increases car prices up to PKR 100,000</a></h3><br>
        <p style="text-align: justify;"><b>KARACHI: </b>Honda Atlas Cars Pakistan has increased prices of its variants by up to Rs100,000, with rupee devaluation denting the company's cost of production.The rate hike is the third made by the company this year, each following the rupee's plunge against the US dollar.</p>
      </div>
      <div>
        <p style="text-align: center;"><a href="#">Read more</a></p>
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="thumbnail">
      <div class="caption">
        <h3 style="text-align: center;"><a href="#">New auto players to invest over $800m in Pakistan</a></h3><br>
        <p style="text-align: justify;"><b>ISLAMABAD: </b>The government has given new projects of five vehicle manufacturing companies including Hyundai, Kia, Regal Automobiles, Khalid Mushtaq Motors and United Motors Greenfield investment status under the Automotive Development Policy 2016-21, which is expected to bring investments of over $800 million to Pakistan.</p>
      </div>
      <div>
        <p style="text-align: center;"><a href="#">Read more</a></p>
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="thumbnail">
      <div class="caption">
        <h3 style="text-align: center;"><a href="#">SC clarifies news item on lowering tax rates on locally-assembled vehicles</a></h3><br>
        <p style="text-align: justify;">“Reference a news story “Supreme Court orders lowering tax rates on locally-assembled vehicles” published in section of media (Express Tribune dated 08.08.2018) and a fake order of Supreme Court, viral on social media, containing number Crl.O.P. NO.2158 of 2018 regarding Price Hike Case against the Automobile Industry in Pakistan.</p>
      </div>
      <div>
        <p style="text-align: center;"><a href="#">Read more</a></p>
      </div>
    </div>
  </div>
      </div>
    </div>
  </section>
  
  <br><br><br>

  <!-- Social bar -->

  <div class="socialbar">
    <div class="container">
      <div class="row">

        <div class="col-md-12">
          <ul>
            <a href="">
              <li><i class="fa fa-facebook"></i>Facebook</li>
            </a>
            <a href="">
              <li><i class="fa fa-twitter"></i>Twitter</li>
            </a>
            <a href="">
              <li><i class="fa fa-instagram"></i>Instagram</li>
            </a>
            <a href="">
              <li><i class="fa fa-youtube-play"></i>Youtube</li>
            </a>
          </ul>
        </div>

      </div>
    </div>
  </div>

<?php include 'includes/footer.php'; ?>