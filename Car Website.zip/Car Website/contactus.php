<?php include 'includes/header.php'; ?>

  <div class="about">
    <h1>Contact Us</h1>
  </div>

  <div class="container">
    <div class="middlecontent">
      <div class="col-md-9">
        <h3 >ASK A QUESTION</h3>
        <input type="text" id="yname" name="yname" placeholder="Your Name">
        <input type="text" id="ymail" name="ymail" placeholder="Your Mail">
        <input class="phonetxt" type="text" name="yphone" placeholder="Your phone number">
        <textarea cols="5" rows="5" placeholder="Your message"></textarea>
        <button type="button" >
          Send now
        </button>
      </div>
    </div>
  </div>
  <br><br><br>

  <!-- Social bar -->

  <div class="socialbar">
    <div class="container">
      <div class="row">

        <div class="col-md-12">
          <ul>
            <a href="">
              <li><i class="fa fa-facebook"></i>Facebook</li>
            </a>
            <a href="">
              <li><i class="fa fa-twitter"></i>Twitter</li>
            </a>
            <a href="">
              <li><i class="fa fa-instagram"></i>Instagram</li>
            </a>
            <a href="">
              <li><i class="fa fa-youtube-play"></i>Youtube</li>
            </a>
          </ul>
        </div>

      </div>
    </div>
  </div>

<?php include 'includes/footer.php'; ?>