<?php include 'includes/header.php'; ?> 

  <div id="slider">

    <div class="container">

      <div class="col-md-5">
        <h1>Karachi Car</h1>
        <h1>Collection</h1>
        <p>We deal in all kinds of automobile and their parts.</p>
        <button type="button">
          SHOP NOW
        </button>
      </div>
    </div>

  </div>

  <section class="benefits">

    <div class="container">

      <h1>Brands We Offer</h1>

      <div class="col-md-4">

        <div class="col">
          <img src="images/hondacar1.jpg" class="img-responsive">

          <h3>Honda</h3>
          <p>Honda Atlas Cars Pakistan Limited is a joint venture between Honda Motor Company Limited Japan, and the Atlas Group of Companies, Pakistan.Percentage of local parts conforms to the government's policy. Local vendors are continuously patronized to develop parts locally. The quality of local parts is thoroughly checked to meet stringent international standards, to achieve customer satisfaction and good value for money.</p>

        </div>
        <a href="./shop.html">
        <button>SHOP NOW</button>
        </a>
      </div>

      <div class="col-md-4">
        <div class="col">
          <img src="images/toyotacar1.jpg" class="img-responsive">

          <h3>Toyota</h3>
          <p>Indus Motor Company Limited (IMC) is a joint venture between certain companies of House of Habib of Pakistan, Toyota Motor Corporation (TMC) and Toyota Tsusho Corporation (TTC) of Japan. Incorporated in 1989, the Company manufactures and markets Toyota brand vehicles in Pakistan.IMC has made large scale investments in enhancing its own capacity and in meeting customer requirements for new products.</p>
        </div>
        <a href="./shop.html">
        <button>SHOP NOW</button>
        </a>
      </div>

      <div class="col-md-4">
        <div class="col">
          <img src="images/suzukicar1.jpg" class="img-responsive">
          <h3>Suzuki</h3>
          <p>Suzuki Motor Corporation designs and manufactures passenger cars, commercial vehicles, motorcycles, all terrain vehicles (ATVs), outboard motors and other products. Pak Suzuki Motor Company Limited (PSMCL) was established, as a joint venture between Pakistan Automobile Corporation (PACO) and Suzuki Motor Corporation (SMC) - Japan. Pak Suzuki is considered pioneer of Automobile Business in Pakistan.</p>

        </div>
        <a href="./shop.html">
        <button>SHOP NOW</button>
        </a>
      </div>

    </div>

  </section>
  
  <section class="div2">
    <div class="container">
     <div class="row">
        <div class="col-md-6">
          <h1>Tesla in Pakistan</h1>
          <p>It is usually not common these days to hear good news but something big is coming related to the automotive market of Pakistan. It is expected that the Prime Minister of Pakistan is going to have a meeting with the executives of Tesla so that they could discuss different investment opportunities that involve the launch of their electric vehicles in Pakistan.<br>

          Javaid Afridi, who is a Pakistani journalist and is also a huge investor in MG Motors Pakistan, has stated that it is highly expected that Tesla might be coming to the automotive market of Pakistan. He has already conducted multiple meetings with Tesla executives and from that, he concluded that Tesla seemed interested to expand its product market in Pakistan.</p>
         
       </div>
       <div class="col-md-6">
        <img src="images/tesla.jpg  " class="img-responsive">
       </div>
      </div>
    </div>
  </section>

  
  <section class="latest">

    <div class="container">

      <h1>Top Selling Cars of The Month</h1>

      <div class="col-md-4">

        <div class="col">
          <img src="images/toyotacar2.png" class="img-responsive">
          <br><br>
          <h4>Toyota Avanza</h4>
        </div>
        <button>Read Reviews</button>
      </div>

      <div class="col-md-4">
        <div class="col">
          <img src="images/daihatsucar.png" width="290" height="400" class="img-responsive">
           <br><br>
          <h4>Daihatsu Terios</h4>
          
        </div>
        <button>Read Reviews</button>
      </div>

      <div class="col-md-4">
        <div class="col">
          <img src="images/topcar3.jpg" class="img-responsive">
          <br><br>
          <h4>Honda City</h4>
          </div>
        <button>Read Reviews</button>
      </div>

    </div>

  </section>
  <br><br><br>

  <div class="socialbar">
    <div class="container">
      <div class="row">

        <div class="col-md-12">
          <ul>
            <a href="">
              <li><i class="fa fa-facebook"></i>Facebook</li>
            </a>
            <a href="">
              <li><i class="fa fa-twitter"></i>Twitter</li>
            </a>
            <a href="">
              <li><i class="fa fa-instagram"></i>Instagram</li>
            </a>
            <a href="">
              <li><i class="fa fa-youtube-play"></i>Youtube</li>
            </a>
          </ul>
        </div>

      </div>
    </div>
  </div>

  <?php include 'includes/footer.php'; ?>