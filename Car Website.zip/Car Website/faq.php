<?php include 'includes/header.php'; ?>

    <div class="about">
        <h1>FAQ</h1>
    </div>

    <div class="container" id="faqContainer">
        <h1>Frequently asked questions</h1>

        <div class="questionContainer">

            <div class="questions" id="q1">
                <p>What are your hours of operation?</p><i class="glyphicon glyphicon-menu-down"></i>
            </div>
            <br>
            <p>The operating hours of all our purchase centres can be found on our website or by calling (021) 111-1111-11.</p>
            <br>
            <div class="questions">
                <p>How can I purchase a car?</p><i class="glyphicon glyphicon-menu-right"></i>
            </div>
            <div class="questions">
                <p>What are the payment methods?</p><i class="glyphicon glyphicon-menu-right"></i>
            </div>
            <div class="questions">
                <p>How long would the total process take?</p><i class="glyphicon glyphicon-menu-right"></i>
            </div>
            <div class="questions">
                <p>What personal information do I need to give?</p><i class="glyphicon glyphicon-menu-right"></i>
            </div>
            <div class="questions">
                <p>Can you quote me a price on phone?</p><i class="glyphicon glyphicon-menu-right"></i>
            </div>
            <div class="questions">
                <p>My car has duplicate number plates, do you still buy it?</p><i class="glyphicon glyphicon-menu-right"></i>
            </div>
            <div class="questions">
                <p>I am a dealer, would you buy my car?</p><i class="glyphicon glyphicon-menu-right"></i>
            </div>
            <div class="questions">
                <p>Do you buy accident or damaged cars?</p><i class="glyphicon glyphicon-menu-right"></i>
            </div>
        </div>
    </div>
    <br><br>


    <!-- Social bar -->

    <div class="socialbar">
        <div class="container">
            <div class="row">

                <div class="col-md-12">
                    <ul>
                        <a href="">
                            <li><i class="fa fa-facebook"></i>Facebook</li>
                        </a>
                        <a href="">
                            <li><i class="fa fa-twitter"></i>Twitter</li>
                        </a>
                        <a href="">
                            <li><i class="fa fa-instagram"></i>Instagram</li>
                        </a>
                        <a href="">
                            <li><i class="fa fa-youtube-play"></i>Youtube</li>
                        </a>
                    </ul>
                </div>

            </div>
        </div>
    </div>

<?php include 'includes/footer.php'; ?>