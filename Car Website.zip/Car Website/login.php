<?php include ('includes/header.php'); ?> 
<?php include('includes/connection.php');?>   
    
<section>
        


    <div class="about" id="signup">


        <h1 id="signup-heading">LOGIN</h1>

        <div id="form-signup">
            <form action="includes/checkUser.php" method="post">
            <input type="text" placeholder="Username/Email Address" name="UName">
            <input type="password" placeholder="Password" name="Pass">
            <div id="chk">
                <input type="checkbox" name="" id="checkbox"> 
                <p>Remember me</p>
                <p id="forgot">Forgot your password?</p>
            </div>

            <button type="submit">Login</button>

            <p><a href="./signup.php">New customer? Signup</a></p>
            </form>
        </div>
    </div>


    <!-- Social bar -->

    <div class="socialbar" id="signup-footer">
        <div class="container">
            <div class="row">

                <div class="col-md-12">
                    <ul>
                        <a href="">
                            <li><i class="fa fa-facebook"></i>Facebook</li>
                        </a>
                        <a href="">
                            <li><i class="fa fa-twitter"></i>Twitter</li>
                        </a>
                        <a href="">
                            <li><i class="fa fa-instagram"></i>Instagram</li>
                        </a>
                        <a href="">
                            <li><i class="fa fa-youtube-play"></i>Youtube</li>
                        </a>
                    </ul>
                </div>

            </div>
        </div>
    </div>

</section>


<?php include 'includes/footer.php'; ?>


