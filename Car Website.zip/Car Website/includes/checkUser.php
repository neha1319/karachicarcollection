<?php
session_start();
$con  = mysqli_connect('localhost','root','','mywebsitedb');
if (isset($_POST['UName']) && isset($_POST['Pass'])) {
    $user = $_POST['UName'];
    $password = $_POST['Pass'];
    $sql1 = "SELECT * From `signupdetail` WHERE `SignupUserName` = '$user' AND `SignupPass` = '$password' ";
if($con->query($sql1))
    {
        $result = $con->query($sql1);
        $res = $result->fetch_array();
        if($res!=NULL)
        {
            $_SESSION['is_user']=1;
            $_SESSION['UName']=$res['UName'];
            header('Location: ../index.php');
        } 
        else
        {
            echo "<script>window.location.href= '../login.php';window.alert('email or Password is incorrect');</script>";
        }
       
    }
}
?>