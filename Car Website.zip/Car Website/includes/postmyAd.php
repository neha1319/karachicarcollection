<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mywebsitedb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['save'])) {

  $PostName=$_POST['postName'];
  $PostUsername=$_POST['postUName'];
  $PostEmail=$_POST['postEmail'];
  $PostPhone=$_POST['postPhone'];
  $PostTitle=$_POST['postTitle'];
  $PostDescription=$_POST['postDescription'];
  $PostCity=$_POST['postCity'];
  $PostBrand=$_POST['postBrand'];
  $PostPrice=$_POST['postPrice'];
  $PostImage=$_POST['postImage'];


  $sql_query ="INSERT INTO postad (PostName,PostUsername,PostEmail,PostPhone,PostTitle,PostDescription,PostCity,PostBrand,PostPrice,PostImage)
  VALUES ('$PostName','$PostUsername','$PostEmail','$PostPhone','$PostTitle','$PostDescription','$PostCity','$PostBrand','$PostPrice','$PostImage') ";

    if (mysqli_query($conn, $sql_query)) {
    echo "New Details Inserted successfully!!";
    header("Refresh:0; url=../search.php");

  }
  else{
    echo "error".$sql."".mysqli_error($conn);
    header("Refresh:0; url=../search.php"); 
  }

  
}
$conn->close();
  ?>
  