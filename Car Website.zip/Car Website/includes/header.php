<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Home</title>

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Oswald&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>

<header>
    

    <div class="navigationBar">



      <div class="container">

        <div class="col-md-3">


        </div>

        <div class="col-md-6">

          <div class="navlink">

            <ul>
              <li><a href="./index.php">HOME</a></li>
              <li><a href="./search.php">SEARCH</a></li>
              <li><a href="./news.php">NEWS</a></li>
              <li><a href="./contactus.php">CONTACT US</a></li>
              <li><a href="./faq.php">FAQ</a></li>
            </ul>

          </div>


        </div>

        <div class="col-md-3">

          <div class="row">
            <div class="column">
              <a href="./login.php">LOGIN</a>
            </div>
            <div class="column">
              <a href="./signup.php">SIGN UP</a>
            </div>
            <div class="column">
              <a href="./postad.php">POST AD</a>
            </div>

          </div>

        </div>

      </div>

    </div>

  </header>