<section class="footer">

    <div class="container">

      <div class="col-md-2">
        <h4>Quick Links</h4>

        <ul>
          <a href="./index.php">
            <li>Home</li>
          </a>
          <a href="./news.html">
            <li>News</li>
          </a>
        </ul>
      </div>

      <div class="col-md-2">
        <h4>Help</h4>

        <ul>
          <a href="./contactus.php">
            <li>Contact Us</li>
          </a>
          <a href="./faq.php">
            <li>FAQ's</li>
          </a>
        </ul>
      </div>

      <div class="col-md-4">
        <h4>Join our mailing list</h4>
        <form type="text">Enter your Email</form>
        <button class="footer-btn">Sign up</button>
      </div>

      

    </div>

  </section>
  <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
  <script src="js/bootstrap.min.js"></script>

</body>

</html>