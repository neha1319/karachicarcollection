<?php
	$mysqli  = new mysqli('localhost', 'root','','mywebsitedb') or die(mysqli_error($mysqli));


        $FName= $_POST['FName'];
        $LName= $_POST['LName'];
        $UName= $_POST['UName'];
        $Pass= $_POST['Pass'];
        $CPass= $_POST['CPass'];
        $mysqli->query("INSERT INTO `signupdetail`(`SignupName`, `SignupLName`, `SignupUserName`,`SignupPass`,`SignupCPass`) VALUES ('$FName','$LName','$UName','$Pass','$CPass')") or die($mysqli->error);
        echo "<script type='text/javascript'>window.location.href= '../login.php';window.alert('Account Registered Successfully');</script>";
        
?>