-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2021 at 10:25 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mywebsitedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `postad`
--

CREATE TABLE `postad` (
  `PostID` int(11) NOT NULL,
  `PostName` varchar(256) NOT NULL,
  `PostUsername` varchar(256) NOT NULL,
  `PostEmail` varchar(256) NOT NULL,
  `PostPhone` varchar(256) NOT NULL,
  `PostTitle` varchar(256) NOT NULL,
  `PostDescription` varchar(256) NOT NULL,
  `PostCity` varchar(256) NOT NULL,
  `PostBrand` varchar(256) NOT NULL,
  `PostPrice` varchar(256) NOT NULL,
  `PostImage` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `postad`
--

INSERT INTO `postad` (`PostID`, `PostName`, `PostUsername`, `PostEmail`, `PostPhone`, `PostTitle`, `PostDescription`, `PostCity`, `PostBrand`, `PostPrice`, `PostImage`) VALUES
(3, 'Nazish', 'nazish123', 'nazish@gmail.com', '12345', 'Honda City for sale', 'TOYOTA VITZ 1000CC AUTOMATIC TRANSMISSION  MODEL 2013 REGISTERED 2017 1ST OWNER  WHITE  COLOUR  72000 KM MILEAGE  (VERIFIABLE AUCTION SHEET) SCRETCHLESS  BODY WITH SOUNDLESS ENGINE AND SUSPENTION  RETRACTABLE SIDE MIRRORS  ABS BRAKE BRAND NEW TYRES , ALLOY', 'Karachi', 'Honda', '80000000', 'searchcar6.jpg'),
(4, 'Jaweria', 'jaweria', 'jaweria@gmail.com', '123456', 'Honda Civic', 'TOYOTA VITZ 1000CC AUTOMATIC TRANSMISSION  MODEL 2013 REGISTERED 2017 1ST OWNER  WHITE  COLOUR  72000 KM MILEAGE  (VERIFIABLE AUCTION SHEET) SCRETCHLESS  BODY WITH SOUNDLESS ENGINE AND SUSPENTION  RETRACTABLE SIDE MIRRORS  ABS BRAKE BRAND NEW TYRES , ALLOY', 'Lahore', 'Honda', '700000', 'searchcar8.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `signupdetail`
--

CREATE TABLE `signupdetail` (
  `SignupID` int(11) NOT NULL,
  `SignupName` varchar(256) NOT NULL,
  `SignupLName` varchar(256) NOT NULL,
  `SignupUsername` varchar(256) NOT NULL,
  `SignupPass` varchar(256) NOT NULL,
  `SignupCPass` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signupdetail`
--

INSERT INTO `signupdetail` (`SignupID`, `SignupName`, `SignupLName`, `SignupUsername`, `SignupPass`, `SignupCPass`) VALUES
(1, 'Mahnoor', 'Farhat', 'mahnoor.farhat@gmail.com', 'abcd', 'abcd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `postad`
--
ALTER TABLE `postad`
  ADD PRIMARY KEY (`PostID`);

--
-- Indexes for table `signupdetail`
--
ALTER TABLE `signupdetail`
  ADD PRIMARY KEY (`SignupID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `postad`
--
ALTER TABLE `postad`
  MODIFY `PostID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `signupdetail`
--
ALTER TABLE `signupdetail`
  MODIFY `SignupID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
