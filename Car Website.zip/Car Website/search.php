<?php include 'includes/header.php'; ?>

<br><br>

  <div style="text-align:center;"><h1><b>Cars & Parts</b></h1></div><br><br>

<div class="container" style="margin-top: 40px; margin-bottom: 40px;">
  <div class="row">
    <div class="col-lg-1" style="margin-left: 235px"><h4><b>Search:</b></h4></div>
  <div class="col-lg-6">
    <div class="input-group">
      
      <input type="text" class="form-control" aria-label="...">
      <div class="input-group-btn">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Filter by <span class="caret"></span></button>
        <ul class="dropdown-menu dropdown-menu-right">
          <li><a href="#">Used cars</a></li>
          <li><a href="#">Price</a></li>
          <li><a href="#">Brand</a></li>
          <li role="separator" class="divider"></li>
          <li><a href="#">Parts</a></li>
        </ul>
      </div><!-- /btn-group -->
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->
</div><!-- /.row -->
</div>

<section>
  <div class="container">
    <div class="col-md-12">
<div class="row">
  <?PHP
        $con = mysqli_connect('localhost', 'root');
        mysqli_select_db($con, 'mywebsitedb');

        $query = " SELECT `PostName`,`PostTitle`, `PostDescription`, `PostCity`, `PostBrand`, `PostPrice`, `PostImage` FROM `postad` ";

        $queryfire = mysqli_query($con, $query);

        $num = mysqli_num_rows($queryfire);

        if ($num > 0) {
          while ($product = mysqli_fetch_array($queryfire)) {
        ?>
            <div class="col-md-4">
              <div class="thumbnail">
                <img src="images/<?php echo $product['PostImage']; ?>" alt="<?php echo $product['PostImage']; ?>" style="height: 350px; width: 425px;">
                <div class="caption">
                  <h3 style="text-align: center;"><?php echo $product['PostName']; ?></h3>
                  <h4 style="text-align: center;"><b><?php echo $product['PostTitle']; ?></b></h4>
                  <p style="text-align: center;"><?php echo $product['PostDescription']; ?></p>
                  <p style="text-align: center;">Brand name:  <?php echo $product['PostBrand']; ?></p>
                  <p style="text-align: center;">City:  <?php echo $product['PostCity']; ?></p>
                  <p style="text-align: center;"><b>Price:  <?php echo $product['PostPrice']; ?></b></p>
                  <p style="margin-left: 49px;"><a href="#" class="btn btn-primary" role="button">Book now</a> <a href="#" class="btn btn-default" role="button">Contact details</a></p>
                </div>
              </div>
            </div>
            <?php
          }
        }
        ?>

  <!--<div class="col-md-4">
    <div class="thumbnail">
      <img src="images/searchcar2.jpg" alt="Toyota Land Cruiser">
      <div class="caption">
        <h3 style="text-align: center;">Toyota Land Cruiser</h3>
        <h5 style="text-align: center;">Toyota Land Cruiser ZX 2016</h5>
        <p style="text-align: center;">Year: 2016</p>
        <p style="text-align: center;">Mileage: 7,000 km</p>
        <p style="text-align: center;">Fuel: Petrol</p>
        <p style="text-align: center;">Engine: 4600 cc</p>
        <p style="text-align: center;">Drive: Automatic</p>
        <p style="text-align: center;">Price: PKR 3.6 crore</p>
        <p style="margin-left: 49px;"><a href="#" class="btn btn-primary" role="button">Book now</a> <a href="#" class="btn btn-default" role="button">Contact details</a></p>
      </div>
    </div>
  </div>


  <div class="col-md-4">
    <div class="thumbnail">
      <img src="images/searchcar3.jpg" alt="Daihatsu Terios Kid">
      <div class="caption">
        <h3 style="text-align: center;">Daihatsu Terios Kid</h3>
        <h5 style="text-align: center;">Daihatsu Terios Kid 2008 Custom L</h5>
        <p style="text-align: center;">Year: 2008</p>
        <p style="text-align: center;">Mileage: 85,000 km</p>
        <p style="text-align: center;">Fuel: Petrol</p>
        <p style="text-align: center;">Engine: 1000 cc</p>
        <p style="text-align: center;">Drive: Manual</p>
        <p style="text-align: center;">Price: PKR 9 lacs</p>
        <p style="margin-left: 49px;"><a href="#" class="btn btn-primary" role="button">Book now</a> <a href="#" class="btn btn-default" role="button">Contact details</a></p>
      </div>
    </div>
  </div>

<div class="col-md-4">
    <div class="thumbnail">
      <img src="images/searchcar4.jpg" alt="Daihatsu Max">
      <div class="caption">
        <h3 style="text-align: center;">Daihatsu Max</h3>
        <h5 style="text-align: center;">Daihatsu Max</h5>
        <p style="text-align: center;">Year: </p>
        <p style="text-align: center;">Mileage: km</p>
        <p style="text-align: center;">Fuel: Petrol</p>
        <p style="text-align: center;">Engine:  cc</p>
        <p style="text-align: center;">Drive: </p>
        <p style="text-align: center;">Price: PKR</p>
        <p style="margin-left: 49px;"><a href="#" class="btn btn-primary" role="button">Book now</a> <a href="#" class="btn btn-default" role="button">Contact details</a></p>
      </div>
    </div>
  </div>

<div class="col-md-4">
    <div class="thumbnail">
      <img src="images/searchcar5.jpg" alt="Honda Accord">
      <div class="caption">
        <h3 style="text-align: center;">Honda Accord</h3>
        <h5 style="text-align: center;"></h5>
        <p style="text-align: center;">Year: </p>
        <p style="text-align: center;">Mileage: km</p>
        <p style="text-align: center;">Fuel: </p>
        <p style="text-align: center;">Engine: cc</p>
        <p style="text-align: center;">Drive: </p>
        <p style="text-align: center;">Price: PKR</p>
        <p style="margin-left: 49px;"><a href="#" class="btn btn-primary" role="button">Book now</a> <a href="#" class="btn btn-default" role="button">Contact details</a></p>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="thumbnail">
      <img src="images/searchcar6.jpg" alt="Toyota Rush">
      <div class="caption">
        <h3 style="text-align: center;">Toyota Rush</h3>
        <h5 style="text-align: center;">Honda City 2018 1.3 i-VTEC</h5>
        <p style="text-align: center;">Year: 2018</p>
        <p style="text-align: center;">Mileage: 21,000 km</p>
        <p style="text-align: center;">Fuel: Petrol</p>
        <p style="text-align: center;">Engine: 1300 cc</p>
        <p style="text-align: center;">Drive: Manual</p>
        <p style="text-align: center;">Price: PKR</p>
        <p style="margin-left: 49px;"><a href="#" class="btn btn-primary" role="button">Book now</a> <a href="#" class="btn btn-default" role="button">Contact details</a></p>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="thumbnail">
      <img src="images/searchcar7.jpg" alt="Hyundayi Accent">
      <div class="caption">
        <h3 style="text-align: center;">Hyundayi Accent</h3>
        <h5 style="text-align: center;">Honda City 2018 1.3 i-VTEC</h5>
        <p style="text-align: center;">Year: 2018</p>
        <p style="text-align: center;">Mileage: 21,000 km</p>
        <p style="text-align: center;">Fuel: Petrol</p>
        <p style="text-align: center;">Engine: 1300 cc</p>
        <p style="text-align: center;">Drive: Manual</p>
        <p style="text-align: center;">Price: PKR</p>
        <p style="margin-left: 49px;"><a href="#" class="btn btn-primary" role="button">Book now</a> <a href="#" class="btn btn-default" role="button">Contact details</a></p>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="thumbnail">
      <img src="images/searchcar10.jpg" alt="Hyundayi Sonata">
      <div class="caption">
        <h3 style="text-align: center;">Hyundayi Sonata</h3>
        <h5 style="text-align: center;">Honda City 2018 1.3 i-VTEC</h5>
        <p style="text-align: center;">Year: 2018</p>
        <p style="text-align: center;">Mileage: 21,000 km</p>
        <p style="text-align: center;">Fuel: Petrol</p>
        <p style="text-align: center;">Engine: 1300 cc</p>
        <p style="text-align: center;">Drive: Manual</p>
        <p style="text-align: center;">Price: PKR</p>
        <p style="margin-left: 49px;"><a href="#" class="btn btn-primary" role="button">Book now</a> <a href="#" class="btn btn-default" role="button">Contact details</a></p>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="thumbnail">
      <img src="images/searchcar9.jpg" alt="Toyota Avanza">
      <div class="caption">
        <h3 style="text-align: center;">Toyota Avanza</h3>
        <h5 style="text-align: center;">Honda City 2018 1.3 i-VTEC</h5>
        <p style="text-align: center;">Year: 2018</p>
        <p style="text-align: center;">Mileage: 21,000 km</p>
        <p style="text-align: center;">Fuel: Petrol</p>
        <p style="text-align: center;">Engine: 1300 cc</p>
        <p style="text-align: center;">Drive: Manual</p>
        <p style="text-align: center;">Price: PKR</p>
        <p style="margin-left: 49px;"><a href="#" class="btn btn-primary" role="button">Book now</a> <a href="#" class="btn btn-default" role="button">Contact details</a></p>
      </div>
    </div>
  </div>-->

</div>
</div>
</div>
</section>
<br><br>

<div class="socialbar">
    <div class="container">
      <div class="row">

        <div class="col-md-12">
          <ul>
            <a href="">
              <li><i class="fa fa-facebook"></i>Facebook</li>
            </a>
            <a href="">
              <li><i class="fa fa-twitter"></i>Twitter</li>
            </a>
            <a href="">
              <li><i class="fa fa-instagram"></i>Instagram</li>
            </a>
            <a href="">
              <li><i class="fa fa-youtube-play"></i>Youtube</li>
            </a>
          </ul>
        </div>

      </div>
    </div>
  </div>

<?php include 'includes/footer.php'; ?>