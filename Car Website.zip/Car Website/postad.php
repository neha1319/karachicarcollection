<?php include 'includes/header.php'; ?>
<?php include('includes/connection.php');?>

<section>
<div class="gradient col-md-12">
  <h1><b>Post Your Ad</b></h1>
<div class="container">
  <div class="col-md-12">
  <form action="includes/postmyAd.php" method="post">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Name</label>
      <input type="text" class="form-control" id="inputEmail4" placeholder="Name" name="postName">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Username</label>
      <input type="text" class="form-control" id="inputPassword4" placeholder="Username" name="postUName">
    </div>
  </div>
  <div class="form-group col-md-6">
    <label for="inputAddress">Email</label>
    <input type="email" class="form-control" id="inputAddress" placeholder="Email" name="postEmail">
  </div>
  <div class="form-group col-md-6">
    <label for="inputAddress2">Phone no.</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="Phone no." name="postPhone">
  </div>
  <div class="form-group col-md-6">
    <label for="inputAddress2">Title</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="Title" name="postTitle">
  </div>
  <div class="form-group col-md-6" style="margin-top: 10px;">
    <label for="exampleFormControlFile1">Choose image</label>
    <input type="file" class="form-control-file" id="exampleFormControlFile1" name="postImage">
  </div>
  <div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputCity">Description</label>
      <input type="text" class="form-control" id="inputCity" placeholder="About your ad" name="postDescription">
    </div>
    <div class="form-group col-md-6">
      <label for="inputCity">City</label>
      <input type="text" class="form-control" id="inputCity" placeholder="City" name="postCity">
    </div>
    <div class="form-group col-md-3">
      <label for="inputCity">City</label>
      <input type="text" class="form-control" id="inputCity" placeholder="Brand name" name="postBrand">
    </div>
    <div class="form-group col-md-3">
      <label for="inputZip">Price</label>
      <input type="text" class="form-control" id="inputZip" placeholder="Rs. " name="postPrice">
    </div>
  </div>
  <div class="form-group">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Hide owner details
      </label>
    </div>
  </div>
  <button type="submit" class="btn btn-primary" name="save">Post Ad</button>
</form>
</div>
</div>  
</div>
</section>

    <div class="socialbar">
    <div class="container">
      <div class="row">

        <div class="col-md-12">
          <ul>
            <a href="">
              <li><i class="fa fa-facebook"></i>Facebook</li>
            </a>
            <a href="">
              <li><i class="fa fa-twitter"></i>Twitter</li>
            </a>
            <a href="">
              <li><i class="fa fa-instagram"></i>Instagram</li>
            </a>
            <a href="">
              <li><i class="fa fa-youtube-play"></i>Youtube</li>
            </a>
          </ul>
        </div>

      </div>
    </div>
  </div>

<?php include 'includes/footer.php'; ?>
